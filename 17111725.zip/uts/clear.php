<?php
    header("Location: index.php?clear=true");
?>
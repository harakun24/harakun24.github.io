<?php
session_start();
if(!isset($_SESSION['data'])){
    $_SESSION['data'] = array(); 
    $_GET['status'] = "standby";
}

if(isset($_POST['simpan'])&&$_GET['status']=="post"){
    array_push(
        $_SESSION['data'],[
            $_POST['Title'],
            $_POST['Authors'],
            $_POST['Publisher'],
            $_POST['kategori']
        ]
    );
            header("Location: index.php");
}
if(isset($_GET['clear'])){
    session_unset();
    header("Location: index.php");
}
?>

<h1>My Library</h1>
<a href="form.php"><button>Add Data</button></a>
<a href="clear.php"><button>clear Data</button></a>
<table>
<tr>
    <th>No</th>
    <th>Title</th>
    <th>Authors</th>
    <th>Publisher</th>
    <th>Category</th>
</tr>
<?php
    // for($i=0;$i<count($_SESSION['data']);$i++){
    //     for($j=0;$j<count($_SESSION['data'][$i]);$j++){
    //         echo "
    //         <td>$i</td>
    //         <td>$_SESSION[data][$i][$j]</td>
    //     ";
    //     }
    // }
    $i=0;
        foreach($_SESSION['data'] as $data){
            echo "
                <tr>
                    <td>".++$i."</td>
                ";
            foreach($data as $col){
                echo "<td>$col</td>";
            }
            echo "</tr>";
        }
?>
</table>
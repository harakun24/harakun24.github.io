<style>
body{
    font-family:arial;
    text-align:center;
    
}
form{
    display:flex;
    text-align:left;
    flex-direction:column;
    width:40%;
    max-width:180px;
    margin-left:30%;
}
input[type=submit]{
    width:40%;
    margin-top:12px;
}
</style>

<form action="index.php?status=post" method="POST">
<h1>Add Book</h1>
    <span>Title: <input type="text" name="Title" required></span>
    <span>Author: <input type="text" name="Authors" required></span>
    <span>Publisher: <input type="text" name="Publisher" required></span>
    <span>Category: <select name="kategori" required>
    <option value="Aplikasi Web">Aplikasi Web</option>
    <option value="Algoritma">Algoritma</option>
    <option value="Statistika">Statistika</option>
    <option value="Artificial Inteligence">Artificial Inteligence</option>
    </select></span>
    <input type="submit" name="simpan" value="simpan">
</form>